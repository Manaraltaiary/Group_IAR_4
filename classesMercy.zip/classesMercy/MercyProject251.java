/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mercyproject251;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class MercyProject251 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        //create a  petOwner object request , username for petowner
        PetOwner petOwner = new PetOwner("XXXX","1234","Saad","0504545454");
        petOwner.aquireSupply(s);
        // numbered list (choose a number"pet owner") => 1.petOwner Username description:---------  
        //customer choose 1
        System.out.println("petOwners in need :-");
        System.out.println(petOwner.toString());
        System.out.println(petOwner.getSupplyDesc());
        
        //fill supply info
           //supply type , name , brief description, Picture(optional)= 1.yes 2.no || customer email, customer phone 
           //the processs is succesfull
           
           
        //create supply object and customer
        //customerUsername = random
        
        //send the object to petOwner Supplysarray
        
/*
        Scanner s = new Scanner(System.in);
        String command = s.next(); //assigning the coomand read by the scanner into variable named command 
        command=command.toLowerCase(); //converting command to lower case
        do { //loop for reading the file 
            switch (command) { //switch for the variable command if the command matches the statment then excute the method for the named command
                case "add_customer":
//                    add_customer(s, customer, output);
                    /*
                    invoking the method that matches the command and sending
                    the Scanner(s), array (customers) and the printwriter(outout)
                    
                    break;
                case "add_itemname":
//                    add_itemName(s, item, output);
                    break;
              
                }
            command = s.next(); // add the next word in file 
            command=command.toLowerCase();//converted to lower case
            if("quit".equals(command)){
//                    quit(output,s);// invoking quit method after the loop ends
                }
        } while (s.hasNext());// check the condition 
    */
}
    
}
