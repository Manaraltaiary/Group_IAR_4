/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mercyproject251;

import java.io.File;

/**
 *
 * @author user
 */
public class Animal {
    String name;
    int age;
    String type;
    String sex;
    File medicalState;
    Picture picture;
    
